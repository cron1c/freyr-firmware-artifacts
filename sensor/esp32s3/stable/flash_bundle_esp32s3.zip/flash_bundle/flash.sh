#!/usr/bin/env bash
# Freyr Sensor -- Initial USB Flash Script (Linux/macOS)
# Usage: ./flash.sh [PORT]   (PORT defaults to /dev/ttyUSB0)
# Requires: pip install esptool

PORT="${1:-/dev/ttyUSB0}"
DIR="$(cd "$(dirname "$0")" && pwd)"

# Read bundle target from metadata
BUNDLE_TARGET=$(python3 -c "
import json, sys
try:
    d = json.load(open('${DIR}/bundle_meta.json'))
    print(d['target'])
except Exception as e:
    print('ERROR reading bundle_meta.json: ' + str(e), file=sys.stderr)
    sys.exit(1)
") || exit 1

# Detect connected chip
echo "Detecting connected chip on ${PORT}..."
CHIP_ID_OUTPUT=$(esptool.py --port "${PORT}" chip_id 2>&1)
DETECTED_CHIP=$(echo "${CHIP_ID_OUTPUT}" | python3 -c "
import sys
text = sys.stdin.read().lower()
if 'esp32-s3' in text:   print('esp32s3')
elif 'esp32-s2' in text: print('esp32s2')
elif 'esp32-c3' in text: print('esp32c3')
elif 'esp32-c6' in text: print('esp32c6')
elif 'esp32-h2' in text: print('esp32h2')
elif 'esp32' in text:    print('esp32')
else:                    print('unknown')
")

if [ "${DETECTED_CHIP}" = "unknown" ]; then
  echo "ERROR: Could not identify connected chip." >&2
  echo "       esptool output:" >&2
  echo "${CHIP_ID_OUTPUT}" | head -10 >&2
  exit 1
fi

if [ "${DETECTED_CHIP}" != "${BUNDLE_TARGET}" ]; then
  echo "ERROR: Bundle target is '${BUNDLE_TARGET}' but connected chip is '${DETECTED_CHIP}'." >&2
  echo "       Use the correct flash bundle for your hardware." >&2
  echo "       Aborting." >&2
  exit 1
fi

echo "Chip validated: ${DETECTED_CHIP} matches bundle target ${BUNDLE_TARGET}"

case "${BUNDLE_TARGET}" in
  esp32) BOOTLOADER_OFFSET=0x1000 ;;
  *)     BOOTLOADER_OFFSET=0x0    ;;
esac

FLASH_ARGS=("${BOOTLOADER_OFFSET}" "${DIR}/bootloader.bin"
  0x8000                  "${DIR}/partition-table.bin")
[ -f "${DIR}/ota_data_initial.bin" ] && \
  FLASH_ARGS+=(0xe000 "${DIR}/ota_data_initial.bin")
FLASH_ARGS+=(0x10000 "${DIR}/firmware.bin")

echo "Flashing Freyr Sensor firmware to ${PORT} (chip: ${BUNDLE_TARGET})"
set -e

# Erase NVS partition so the device starts fresh provisioning.
echo "Erasing NVS partition (0x9000, 0x5000)..."
esptool.py --chip "${BUNDLE_TARGET}" --port "${PORT}" --baud 460800 erase-region 0x9000 0x5000

esptool.py --chip "${BUNDLE_TARGET}" --port "${PORT}" --baud 460800 write-flash "${FLASH_ARGS[@]}"
echo "Done. Power-cycle the device."
