# Freyr Sensor -- Initial USB Flash Script (Windows PowerShell)
# Usage: .\flash.ps1 [PORT]   (PORT defaults to COM3)
# Requires: pip install esptool

param([string]$Port = "COM3")

$Dir = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Read bundle target from metadata
$MetaPath = "$Dir\bundle_meta.json"
if (-not (Test-Path $MetaPath)) {
    Write-Error "bundle_meta.json not found in bundle. Cannot validate chip."
    exit 1
}
$Meta = Get-Content $MetaPath | ConvertFrom-Json
$BundleTarget = $Meta.target

# Detect connected chip
Write-Host "Detecting connected chip on $Port..."
$ChipIdOutput = & esptool.py --port $Port chip_id 2>&1 | Out-String
$DetectedChip = python3 -c @"
text = r'''$ChipIdOutput'''.lower()
if 'esp32-s3' in text:   print('esp32s3')
elif 'esp32-s2' in text: print('esp32s2')
elif 'esp32-c3' in text: print('esp32c3')
elif 'esp32-c6' in text: print('esp32c6')
elif 'esp32-h2' in text: print('esp32h2')
elif 'esp32' in text:    print('esp32')
else:                    print('unknown')
"@

if ($DetectedChip -eq "unknown") {
    Write-Error "Could not identify connected chip."
    exit 1
}

if ($DetectedChip -ne $BundleTarget) {
    Write-Error "Bundle target is '$BundleTarget' but connected chip is '$DetectedChip'.`nUse the correct flash bundle for your hardware.`nAborting."
    exit 1
}

Write-Host "Chip validated: $DetectedChip matches bundle target $BundleTarget"

$BootloaderOffset = if ($BundleTarget -eq "esp32") { "0x1000" } else { "0x0" }

$FlashArgs = @(
    "--chip", $BundleTarget,
    "--port", $Port,
    "--baud", "460800",
    "write-flash",
    $BootloaderOffset, "$Dir\bootloader.bin",
    "0x8000",          "$Dir\partition-table.bin"
)
if (Test-Path "$Dir\ota_data_initial.bin") {
    $FlashArgs += "0xe000", "$Dir\ota_data_initial.bin"
}
$FlashArgs += "0x10000", "$Dir\firmware.bin"

Write-Host "Flashing Freyr Sensor firmware to $Port (chip: $BundleTarget)"

# Erase NVS so the device starts fresh provisioning after reflash
Write-Host "Erasing NVS partition (0x9000, 0x5000)..."
& esptool.py --chip $BundleTarget --port $Port --baud 460800 erase-region 0x9000 0x5000
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& esptool.py @FlashArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Done. Power-cycle the device."
