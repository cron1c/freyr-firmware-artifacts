Freyr Sensor -- Initial USB Flash Bundle
Version: 0.1.0
Chip:    esp32
========================================

Prerequisites
-------------
1. Install Python 3.8+ from https://python.org
2. Install esptool:
     pip install esptool

Linux / macOS
-------------
1. Connect the device via USB.
2. Identify the serial port (e.g. /dev/ttyUSB0 or /dev/cu.usbserial-*).
   You can run:  esptool.py chip_id
   to auto-detect the port and confirm the chip type.
3. Run:
     chmod +x flash.sh
     ./flash.sh /dev/ttyUSB0

Windows (PowerShell)
--------------------
1. Connect the device via USB.
2. Open Device Manager -> Ports (COM & LPT) to find the COM port.
3. Run:
     .\flash.ps1 COM3

Chip reference
--------------
This bundle targets: esp32
Other supported chips: esp32, esp32s2, esp32s3
If your board differs, re-flash using the correct firmware build.

Flash map
---------
0x001000  bootloader.bin
0x008000  partition-table.bin
0x00D000  ota_data_initial.bin
0x010000  firmware.bin
