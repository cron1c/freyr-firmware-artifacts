#!/usr/bin/env bash
# Freyr Sensor — Initial USB Flash Script (Linux/macOS)
# Usage: ./flash.sh [PORT]
#   PORT defaults to /dev/ttyUSB0
#
# Requires: pip install esptool

CHIP=esp32
PORT="${1:-/dev/ttyUSB0}"
DIR="$(cd "$(dirname "$0")" && pwd)"

case "${CHIP}" in
  esp32)  BOOTLOADER_OFFSET=0x1000 ;;
  *)      BOOTLOADER_OFFSET=0x0    ;;
esac

echo "Flashing Freyr Sensor firmware to ${PORT} (chip: ${CHIP})"
set -e

esptool.py --chip "${CHIP}" --port "${PORT}" --baud 460800 \
  write_flash \
  "${BOOTLOADER_OFFSET}" "${DIR}/bootloader.bin" \
  0x8000 "${DIR}/partition-table.bin" \
  0xD000 "${DIR}/ota_data_initial.bin" \\   0x10000 "${DIR}/firmware.bin"

echo "Done. Power-cycle the device."
