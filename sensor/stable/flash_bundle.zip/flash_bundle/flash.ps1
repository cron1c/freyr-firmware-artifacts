# Freyr Sensor -- Initial USB Flash Script (Windows PowerShell)
# Usage: .\flash.ps1 [PORT]   (PORT defaults to COM3)
# Requires: pip install esptool

param([string]$Port = "COM3")

$Chip = "esp32"
$Dir  = Split-Path -Parent $MyInvocation.MyCommand.Definition

$BootloaderOffset = if ($Chip -eq "esp32") { "0x1000" } else { "0x0" }

$FlashArgs = @(
    "--chip", $Chip,
    "--port", $Port,
    "--baud", "460800",
    "write-flash",
    $BootloaderOffset, "$Dir\bootloader.bin",
    "0x8000",          "$Dir\partition-table.bin"
)
if (Test-Path "$Dir\ota_data_initial.bin") {
    $FlashArgs += "0xe000", "$Dir\ota_data_initial.bin"
}
$FlashArgs += "0x10000", "$Dir\firmware.bin"

Write-Host "Flashing Freyr Sensor firmware to $Port (chip: $Chip)"

# Erase NVS so the device starts fresh provisioning after reflash
Write-Host "Erasing NVS partition (0x9000, 0x5000)..."
& esptool.py --chip $Chip --port $Port --baud 460800 erase-region 0x9000 0x5000
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& esptool.py @FlashArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Done. Power-cycle the device."
