# Freyr Sensor — Initial USB Flash Script (Windows PowerShell)
# Usage: .\flash.ps1 [PORT]
#   PORT defaults to COM3
#
# Requires: pip install esptool

param([string]$Port = "COM3")

$Chip = "esp32"
$Dir  = Split-Path -Parent $MyInvocation.MyCommand.Definition

$BootloaderOffset = if ($Chip -eq "esp32") { "0x1000" } else { "0x0" }

Write-Host "Flashing Freyr Sensor firmware to $Port (chip: $Chip)"

$FlashArgs = @(
    "--chip", $Chip,
    "--port", $Port,
    "--baud", "460800",
    "write_flash",
    $BootloaderOffset, "$Dir\bootloader.bin",
    "0x8000", "$Dir\partition-table.bin",
    "0xD000", "$Dir\ota_data_initial.bin",
    "0x10000", "$Dir\firmware.bin"
)

& esptool.py @FlashArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Done. Power-cycle the device."
